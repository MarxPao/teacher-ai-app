@echo off
start "" pythonw "%~dp0sidecar\manual_runner.py" --tray
