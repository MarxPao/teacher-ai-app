@echo off
echo Registrando inicializacao automatica para o usuario atual (HKCU)...
python "%~dp0sidecar\setup_scheduled_task.py" --action install
pause
