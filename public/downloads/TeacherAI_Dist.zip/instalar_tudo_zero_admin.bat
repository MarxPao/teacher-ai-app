@echo off
echo ====================================================
echo   Instalacao do Teacher AI (Zero Privilegios Admin)
echo ====================================================
python "%~dp0sidecar\native_host\register_host.py" --action register
python "%~dp0sidecar\setup_scheduled_task.py" --action install
echo.
echo Iniciando o agente do Teacher AI em segundo plano...
start "" pythonw "%~dp0sidecar\manual_runner.py" --tray
echo Instalacao concluida com sucesso!
pause
