@echo off
echo Registrando Native Messaging Host para o Google Chrome (HKCU)...
python "%~dp0sidecar\native_host\register_host.py" --action register
pause
